const functions = require('firebase-functions');
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const admin = require('firebase-admin');
const crypto = require('crypto');
const diagnosePage = require('./diagnosePage');

// Initialize Firebase Admin SDK
admin.initializeApp();

// Create our own simple Express app just for Firebase Functions
const app = express();

// Add middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());

// Simple in-memory session store (this would be a database in production)
// IMPORTANT: This is NOT suitable for production use as it resets when the function instance is recycled
// In a real app, use Firestore, Firebase RTDB, or another persistent database for sessions
let sessions = {};
console.log('Initializing session store');

// Initialize Firestore for persistent session storage
const db = admin.firestore();
const sessionsCollection = db.collection('sessions');
console.log('Initialized Firestore for persistent sessions');

// URL shortening utilities
// Create an in-memory store for URL mappings
let urlMappings = {};

// Create a Firestore collection for URL mappings
const urlMappingsCollection = db.collection('urlMappings');

// Initialize click tracking collection in Firestore
const clicksCollection = db.collection('clicks');

// Load existing URL mappings from Firestore
async function loadUrlMappingsFromFirestore() {
  try {
    const snapshot = await urlMappingsCollection.get();
    snapshot.forEach(doc => {
      const mapping = doc.data();
      urlMappings[doc.id] = mapping.url;
      console.log(`Loaded URL mapping from Firestore: ${doc.id} -> ${mapping.url}`);
    });
    console.log(`Loaded ${snapshot.size} URL mappings from Firestore`);
  } catch (error) {
    console.error('Error loading URL mappings from Firestore:', error);
    // Initialize with some default mappings if Firestore access fails
    console.log('Initializing with default URL mappings');
    
    // Set default mapping for example.com
    urlMappings['c984d0'] = 'https://example.com';
  }
}

// Call this function at server startup
loadUrlMappingsFromFirestore();

// Function to create a short code for a URL
async function createShortCode(url) {
  // First check if we already have a code for this URL
  for (const [code, storedUrl] of Object.entries(urlMappings)) {
    if (storedUrl === url) {
      return code;
    }
  }
  
  // If not, create a new short code
  // Use the first 6 characters of the MD5 hash for uniqueness
  const hash = crypto.createHash('md5').update(url).digest('hex');
  const shortCode = hash.substring(0, 6);
  
  // Store the mapping
  urlMappings[shortCode] = url;
  
  // Also persist in Firestore
  try {
    await urlMappingsCollection.doc(shortCode).set({ url });
    console.log(`Stored URL mapping in Firestore: ${shortCode} -> ${url}`);
  } catch (error) {
    console.error('Error storing URL mapping in Firestore:', error);
    // We can continue even if Firestore persistence fails
    // The mapping is still in memory for this instance
  }
  
  console.log(`Created new short code ${shortCode} for ${url}`);
  
  return shortCode;
}

// Function to retrieve a URL from a short code
async function getUrlFromShortCode(code) {
  // First check in-memory cache
  if (urlMappings[code]) {
    return urlMappings[code];
  }
  
  // If not found, check Firestore
  try {
    const doc = await urlMappingsCollection.doc(code).get();
    if (doc.exists) {
      const mapping = doc.data();
      // Add to in-memory cache
      urlMappings[code] = mapping.url;
      return mapping.url;
    }
  } catch (error) {
    console.error('Error fetching URL mapping from Firestore:', error);
  }
  
  return null;
}

// Add a function to track clicks
async function trackClick(shortCode, decodedUrl, userAgent, referrer, ip, cfCountry) {
  try {
    console.log(`Starting click tracking for shortcode: ${shortCode}, target: ${decodedUrl}`);
    
    // Ensure shortCode is valid before proceeding
    if (!shortCode) {
      console.error('Invalid shortCode provided to trackClick');
      return { success: false, error: 'Invalid shortCode' };
    }
    
    const timestamp = admin.firestore.FieldValue.serverTimestamp();
    const day = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
    
    // Generate a unique ID for this click
    const clickId = crypto.randomBytes(16).toString('hex');
    
    // Use country from Cloudflare if available, otherwise 'Unknown'
    let country = cfCountry || 'Unknown';
    console.log(`Country for click: ${country}, IP: ${ip}`);
    
    // Log key parts of the tracking for debugging
    console.log('Creating click with data:', JSON.stringify({
      clickId,
      shortCode,
      decodedUrl,
      userAgent: userAgent ? userAgent.substring(0, 50) + '...' : null,
      ip: ip ? ip.substring(0, 15) + '...' : null,
      country,
      day
    }));
    
    // Try a series of fallback mechanisms to ensure tracking works
    let docRef = null;
    let succeeded = false;
    
    // Fallback 1: Try normal document creation
    try {
      docRef = clicksCollection.doc(clickId);
      await docRef.set({
        type: 'click',
        shortCode,
        targetUrl: decodedUrl,
        userAgent: userAgent || null,
        referrer: referrer || null,
        ip: ip || null,
        country,
        timestamp,
        day,
        processed: true,
        attempt: 1
      });
      
      // Verify the document exists
      const verifyDoc = await docRef.get();
      if (verifyDoc.exists) {
        console.log(`Click tracking succeeded: Document created with ID ${clickId}`);
        succeeded = true;
      } else {
        console.warn(`Document created but not found on verification: ${clickId}`);
      }
    } catch (error) {
      console.error(`Fallback 1 (document creation) failed: ${error.message}`);
    }
    
    // Fallback 2: Try with minimal data
    if (!succeeded) {
      try {
        docRef = clicksCollection.doc(`minimal-${clickId}`);
        await docRef.set({
          type: 'click',
          shortCode,
          targetUrl: decodedUrl,
          country,
          timestamp,
          day,
          attempt: 2,
          minimal: true
        });
        
        // Verify the document exists
        const verifyDoc = await docRef.get();
        if (verifyDoc.exists) {
          console.log(`Click tracking succeeded with minimal data: Document ID ${docRef.id}`);
          succeeded = true;
          clickId = docRef.id;
        } else {
          console.warn(`Minimal document created but not found on verification: ${docRef.id}`);
        }
      } catch (error) {
        console.error(`Fallback 2 (minimal document) failed: ${error.message}`);
      }
    }
    
    // Fallback 3: Use auto-generated ID
    if (!succeeded) {
      try {
        const autoRef = await clicksCollection.add({
          type: 'click',
          shortCode,
          targetUrl: decodedUrl,
          country,
          timestamp,
          day,
          attempt: 3,
          auto: true
        });
        
        console.log(`Click tracking succeeded with auto-generated ID: ${autoRef.id}`);
        succeeded = true;
        clickId = autoRef.id;
      } catch (error) {
        console.error(`Fallback 3 (auto ID) failed: ${error.message}`);
      }
    }
    
    // Try to update the summary document, but don't block if it fails
    try {
      console.log(`Updating summary document for shortcode: ${shortCode}`);
      const summaryRef = clicksCollection.doc(`summary_${shortCode}`);
      
      await summaryRef.set({
        type: 'summary',
        shortCode,
        targetUrl: decodedUrl,
        totalClicks: admin.firestore.FieldValue.increment(1),
        lastClickAt: timestamp,
        [`clicks_${day}`]: admin.firestore.FieldValue.increment(1),
        [`country_${country}`]: admin.firestore.FieldValue.increment(1)
      }, { merge: true });
      
      console.log(`Successfully updated summary document for ${shortCode}`);
    } catch (summaryError) {
      console.error(`Error updating summary document: ${summaryError.message}`);
      
      // Try a simpler approach if the first one fails
      try {
        const simpleSummaryRef = clicksCollection.doc(`simple_summary_${shortCode}`);
        await simpleSummaryRef.set({
          type: 'summary',
          shortCode,
          targetUrl: decodedUrl,
          totalClicks: 1, // Don't use increment to minimize chances of failure
          lastClickAt: new Date().toISOString(), // Use string instead of server timestamp
          day
        }, { merge: true });
        
        console.log(`Updated simplified summary document for ${shortCode}`);
      } catch (simpleSummaryError) {
        console.error(`Error updating simplified summary document: ${simpleSummaryError.message}`);
      }
    }
    
    if (succeeded) {
      console.log(`Click successfully tracked for ${shortCode}, country: ${country}, ID: ${clickId}`);
      return { success: true, clickId };
    } else {
      console.error(`All tracking attempts failed for ${shortCode}`);
      
      // Create an in-memory record as a last resort
      // This won't persist across function invocations but might help debug
      if (!global.inMemoryClicks) global.inMemoryClicks = [];
      global.inMemoryClicks.push({
        shortCode,
        targetUrl: decodedUrl,
        timestamp: new Date().toISOString(),
        country,
        day
      });
      console.log(`Stored click in memory as last resort, current memory clicks: ${global.inMemoryClicks.length}`);
      
      return { success: false, error: 'All tracking attempts failed' };
    }
  } catch (error) {
    console.error('Unhandled error in trackClick:', error);
    return { success: false, error: error.message };
  }
}

// Helper functions for session management
async function createSession(email, uid) {
  const sessionToken = Math.random().toString(36).substring(2, 15);
  const sessionData = {
    email,
    uid,
    loggedIn: true,
    createdAt: new Date().toISOString()
  };
  
  // Store in Firestore
  await sessionsCollection.doc(sessionToken).set(sessionData);
  console.log('Created persistent session:', sessionToken);
  
  // Also keep in memory for faster access
  sessions[sessionToken] = sessionData;
  
  return sessionToken;
}

async function getSession(sessionToken) {
  if (!sessionToken) return null;
  
  // First try memory cache
  if (sessions[sessionToken]) {
    return sessions[sessionToken];
  }
  
  // If not in memory, try Firestore
  try {
    const sessionDoc = await sessionsCollection.doc(sessionToken).get();
    if (sessionDoc.exists) {
      const sessionData = sessionDoc.data();
      // Cache in memory
      sessions[sessionToken] = sessionData;
      return sessionData;
    }
  } catch (error) {
    console.error('Error fetching session:', error);
  }
  
  return null;
}

async function deleteSession(sessionToken) {
  if (!sessionToken) return;
  
  // Delete from Firestore
  try {
    await sessionsCollection.doc(sessionToken).delete();
    // Also remove from memory cache
    delete sessions[sessionToken];
  } catch (error) {
    console.error('Error deleting session:', error);
  }
}

// Add an API endpoint for URL shortening
app.post('/api/shorten', async (req, res) => {
  try {
    const url = req.body.url;
    
    // Validate URL
    if (!url) {
      return res.status(400).json({ error: 'URL is required' });
    }
    
    try {
      // Make sure it's a valid URL
      new URL(url);
    } catch (e) {
      return res.status(400).json({ error: 'Invalid URL format' });
    }
    
    // Create a short code
    const shortCode = await createShortCode(url);
    
    // Create the full short URL - use the custom domain
    const shortUrl = `https://dlzz.pro/r/${shortCode}`;
    
    // Return the short URL
    res.json({
      originalUrl: url,
      shortCode,
      shortUrl
    });
  } catch (error) {
    console.error('Error shortening URL:', error);
    res.status(500).json({ error: 'Error shortening URL' });
  }
});

// API endpoint to get click statistics
app.get('/api/click-stats', async (req, res) => {
  try {
    console.log('API Request: Getting click statistics - debugging enhanced version');
    
    // Get summary documents
    let stats = [];
    let firestoreError = null;
    
    try {
      console.log('Fetching documents from clicks collection');
      
      // Log what's actually in the collection first
      const allClicks = await clicksCollection.get();
      console.log(`TOTAL DOCUMENTS IN COLLECTION: ${allClicks.size}`);
      allClicks.forEach(doc => {
        console.log(`Document ID: ${doc.id}, Data:`, JSON.stringify(doc.data()));
      });
      
      // First, try to get summary documents
      const summarySnapshot = await clicksCollection.where('type', '==', 'summary').get();
      console.log(`Found ${summarySnapshot.size} summary documents`);
      
      if (!summarySnapshot.empty) {
        summarySnapshot.forEach(doc => {
          const data = doc.data();
          console.log(`Processing summary doc ${doc.id}:`, JSON.stringify(data));
          processStatData(data, stats);
        });
        console.log(`Processed ${stats.length} summary documents into stats`);
      }
      
      // If no summary docs found, fetch individual click documents
      if (stats.length === 0) {
        console.log('No summary documents found, fetching individual click documents');
        
        const clickSnapshot = await clicksCollection.where('type', '==', 'click').get();
        console.log(`Found ${clickSnapshot.size} individual click documents`);
        
        clickSnapshot.forEach(doc => {
          console.log(`Click document found: ${doc.id}`, JSON.stringify(doc.data()));
        });
        
        if (clickSnapshot.empty && stats.length === 0) {
          // If still no data, fall back to URL mappings
          const mappingsSnapshot = await urlMappingsCollection.get();
          console.log(`No click data found. Falling back to URL mappings, found ${mappingsSnapshot.size} mappings`);
          
          mappingsSnapshot.forEach(doc => {
            const shortCode = doc.id;
            const url = doc.data().url;
            console.log(`URL mapping: ${shortCode} -> ${url}`);
            
            if (shortCode && url) {
              stats.push({
                shortCode,
                targetUrl: url,
                totalClicks: 0,
                lastClickAt: null,
                avgClicksPerDay: 0,
                countryData: {},
                dailyClickData: {},
                recentClicks: []
              });
            }
          });
        } else {
          // Group clicks by shortCode
          const clicksByShortCode = {};
          
          clickSnapshot.forEach(doc => {
            const clickData = doc.data();
            if (!clickData.shortCode) {
              console.log(`Click document ${doc.id} missing shortCode, skipping`);
              return;
            }
            
            if (!clicksByShortCode[clickData.shortCode]) {
              clicksByShortCode[clickData.shortCode] = [];
            }
            
            clicksByShortCode[clickData.shortCode].push({
              timestamp: clickData.timestamp ? clickData.timestamp.toDate() : new Date(),
              targetUrl: clickData.targetUrl,
              userAgent: clickData.userAgent || '',
              referrer: clickData.referrer || '',
              country: clickData.country || 'Unknown',
              day: clickData.day || new Date().toISOString().split('T')[0]
            });
          });
          
          console.log(`Grouped clicks by shortCode, found ${Object.keys(clicksByShortCode).length} unique shortcodes`);
          Object.keys(clicksByShortCode).forEach(code => {
            console.log(`ShortCode ${code} has ${clicksByShortCode[code].length} clicks`);
          });
          
          // Generate stats from grouped clicks
          for (const [shortCode, clicks] of Object.entries(clicksByShortCode)) {
            console.log(`Processing ${clicks.length} clicks for shortCode ${shortCode}`);
            
            // Get the target URL from clicks or mapping
            let targetUrl = clicks.length > 0 && clicks[0].targetUrl 
              ? clicks[0].targetUrl 
              : null;
              
            if (!targetUrl) {
              const urlDoc = await urlMappingsCollection.doc(shortCode).get();
              if (urlDoc.exists) {
                targetUrl = urlDoc.data().url;
              } else {
                targetUrl = 'Unknown URL';
              }
            }
            
            console.log(`Target URL for ${shortCode}: ${targetUrl}`);
            
            // Count clicks by day and country
            const dayClicks = {};
            const countryClicks = {};
            
            clicks.forEach(click => {
              // Count by day
              const day = click.day || new Date().toISOString().split('T')[0]; // Fallback to today
              dayClicks[day] = (dayClicks[day] || 0) + 1;
              
              // Count by country
              const country = click.country || 'Unknown';
              countryClicks[country] = (countryClicks[country] || 0) + 1;
            });
            
            // Sort clicks by timestamp (newest first)
            clicks.sort((a, b) => {
              return new Date(b.timestamp) - new Date(a.timestamp);
            });
            
            // Create a stat record
            stats.push({
              shortCode,
              targetUrl,
              totalClicks: clicks.length,
              lastClickAt: clicks.length > 0 ? clicks[0].timestamp : null,
              avgClicksPerDay: Object.keys(dayClicks).length > 0 
                ? clicks.length / Object.keys(dayClicks).length 
                : clicks.length,
              countryData: countryClicks,
              dailyClickData: dayClicks,
              recentClicks: clicks.slice(0, 50) // Limit to last 50 clicks
            });
          }
        }
      }
      
      // Sort by total clicks (descending)
      stats.sort((a, b) => b.totalClicks - a.totalClicks);
      
      console.log(`Found ${stats.length} statistics entries from Firestore`);
    } catch (error) {
      console.error('Error accessing Firestore:', error);
      firestoreError = error.message;
      // Continue to check for in-memory clicks
    }
    
    // Check for in-memory clicks if no Firestore data was found
    if (stats.length === 0 && global.inMemoryClicks && global.inMemoryClicks.length > 0) {
      console.log(`No Firestore stats found, but ${global.inMemoryClicks.length} in-memory clicks exist`);
      
      // Group in-memory clicks by shortCode
      const clicksByShortCode = {};
      
      global.inMemoryClicks.forEach(click => {
        if (!clicksByShortCode[click.shortCode]) {
          clicksByShortCode[click.shortCode] = [];
        }
        
        clicksByShortCode[click.shortCode].push({
          timestamp: new Date(click.timestamp),
          targetUrl: click.targetUrl,
          country: click.country || 'Unknown',
          day: click.day
        });
      });
      
      // Generate stats from in-memory clicks
      for (const [shortCode, clicks] of Object.entries(clicksByShortCode)) {
        const targetUrl = clicks[0].targetUrl;
        
        // Count clicks by day and country
        const dayClicks = {};
        const countryClicks = {};
        
        clicks.forEach(click => {
          dayClicks[click.day] = (dayClicks[click.day] || 0) + 1;
          countryClicks[click.country] = (countryClicks[click.country] || 0) + 1;
        });
        
        // Sort clicks by timestamp (newest first)
        clicks.sort((a, b) => b.timestamp - a.timestamp);
        
        stats.push({
          shortCode,
          targetUrl,
          totalClicks: clicks.length,
          lastClickAt: clicks[0].timestamp,
          avgClicksPerDay: Object.keys(dayClicks).length > 0 
            ? clicks.length / Object.keys(dayClicks).length 
            : clicks.length,
          countryData: countryClicks,
          dailyClickData: dayClicks,
          recentClicks: clicks.slice(0, 50),
          source: 'memory' // Mark these as coming from memory
        });
      }
      
      console.log(`Added ${stats.length} stat entries from in-memory clicks`);
    }
    
    // Enhance the response with diagnostic info
    const response = { 
      stats,
      meta: {
        totalStats: stats.length,
        firestoreError: firestoreError,
        memoryClicksAvailable: global.inMemoryClicks && global.inMemoryClicks.length > 0,
        memoryClicksCount: global.inMemoryClicks ? global.inMemoryClicks.length : 0,
        functionInstance: crypto.randomBytes(4).toString('hex'),
        timestamp: new Date().toISOString()
      }
    };
    
    res.json(response);
  } catch (error) {
    console.error('Error fetching click stats:', error);
    res.status(500).json({ 
      error: 'Error fetching click statistics',
      message: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Helper function to process stat data
function processStatData(data, stats) {
  if (!data.shortCode) return;
  
  // Calculate daily average
  let totalDailyClicks = 0;
  let daysWithClicks = 0;
  let dailyClickData = {};
  
  // Look for daily click data (fields starting with "clicks_")
  Object.keys(data).forEach(key => {
    if (key.startsWith('clicks_')) {
      const day = key.replace('clicks_', '');
      const clicks = data[key];
      
      dailyClickData[day] = clicks;
      totalDailyClicks += clicks;
      daysWithClicks++;
    }
  });
  
  const avgClicksPerDay = daysWithClicks > 0
    ? (totalDailyClicks / daysWithClicks).toFixed(1)
    : 0;
  
  // Extract country data
  const countryData = {};
  Object.keys(data).forEach(key => {
    if (key.startsWith('country_')) {
      const country = key.replace('country_', '');
      countryData[country] = data[key];
    }
  });
  
  stats.push({
    shortCode: data.shortCode,
    targetUrl: data.targetUrl,
    totalClicks: data.totalClicks || 0,
    lastClickAt: data.lastClickAt ? data.lastClickAt.toDate() : null,
    avgClicksPerDay: Number(avgClicksPerDay),
    countryData,
    dailyClickData
  });
}

// Handle redirect links - this is a special case for affiliate link tracking
// Format: /r/SHORT_CODE to track and redirect
app.get('/r/:targetUrl', async (req, res) => {
  console.log(`==== REDIRECT REQUEST STARTED ====`);
  try {
    const encodedUrl = req.params.targetUrl;
    let decodedUrl;
    let shortCode = encodedUrl; // Use the encoded URL as the short code
    
    console.log(`Redirect request for code: ${shortCode}`);
    
    // Check if this is a short code in our mappings
    const storedUrl = await getUrlFromShortCode(encodedUrl);
    if (storedUrl) {
      decodedUrl = storedUrl;
      console.log(`Found URL mapping for code ${encodedUrl}: ${decodedUrl}`);
    } else {
      // If no mapping exists, redirect to home page
      console.log(`No URL mapping found for code ${encodedUrl}`);
      res.redirect('/');
      return;
    }
    
    // Extract and log headers for tracking
    const headers = req.headers;
    console.log('Request headers:', JSON.stringify({
      'user-agent': headers['user-agent'],
      'referer': headers['referer'] || headers['referrer'],
      'x-forwarded-for': headers['x-forwarded-for'],
      'cf-ipcountry': headers['cf-ipcountry'] // Cloudflare provides this if used
    }));
    
    // Capture relevant information for tracking
    const userAgent = req.headers['user-agent'] || '';
    const referrer = req.headers['referer'] || req.headers['referrer'] || '';
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress || '';
    const cfCountry = req.headers['cf-ipcountry'] || 'Unknown';
    
    // Track the click and ensure it completes before redirecting
    let trackingSucceeded = false;
    let clickId = null;
    
    console.log(`Attempting to track click for shortcode: ${shortCode}`);
    
    try {
      // Check if Firestore is accessible before attempting to track
      try {
        const testDoc = await clicksCollection.doc('test-connectivity').get();
        console.log(`Firestore connectivity test: ${testDoc.exists ? 'Success' : 'Document does not exist but connection works'}`);
      } catch (connectError) {
        console.error(`Firestore connectivity test failed: ${connectError}`);
      }
      
      // Use Promise.race to either get the tracking result or timeout
      const result = await Promise.race([
        trackClick(shortCode, decodedUrl, userAgent, referrer, ip, cfCountry),
        new Promise((resolve) => {
          setTimeout(() => {
            console.log(`Click tracking timed out for ${shortCode}, proceeding with redirect`);
            resolve({ success: false, error: 'Tracking timeout' });
          }, 2000); // Increased timeout to 2 seconds to ensure tracking completes
        })
      ]);
      
      if (result && result.success) {
        trackingSucceeded = true;
        clickId = result.clickId;
        console.log(`Click tracked successfully with ID: ${result.clickId}`);
      } else {
        console.error(`Click tracking had issues: ${result ? result.error : 'unknown error'}`);
        
        // Try direct document creation as a fallback
        try {
          console.log('Attempting direct document creation for click tracking');
          // Generate a unique ID for this click
          const directClickId = crypto.randomBytes(16).toString('hex');
          
          const clickDocRef = clicksCollection.doc(directClickId);
          await clickDocRef.set({
            type: 'click',
            shortCode,
            targetUrl: decodedUrl,
            userAgent: userAgent || null,
            referrer: referrer || null,
            ip: ip || null,
            country: cfCountry || 'Unknown',
            timestamp: admin.firestore.FieldValue.serverTimestamp(),
            day: new Date().toISOString().split('T')[0],
            directCreated: true // Mark this as being created directly
          });
          
          const clickDoc = await clickDocRef.get();
          console.log(`Direct document creation result: ${clickDoc.exists ? 'Success' : 'Failed'}, data:`, 
            clickDoc.exists ? JSON.stringify(clickDoc.data()) : 'No data');
          
          trackingSucceeded = true;
          clickId = directClickId;
        } catch (directError) {
          console.error(`Direct document creation failed: ${directError}`);
          
          // Directly write to Firestore as a final fallback
          try {
            console.log('Attempting emergency click tracking with minimal data');
            const emergencyClickRef = await clicksCollection.add({
              type: 'click',
              shortCode,
              targetUrl: decodedUrl,
              timestamp: admin.firestore.FieldValue.serverTimestamp(),
              day: new Date().toISOString().split('T')[0],
              country: cfCountry || 'Unknown',
              emergency: true
            });
            
            console.log(`Emergency click tracking succeeded with ID: ${emergencyClickRef.id}`);
            
            // Also update the summary document
            const summaryRef = clicksCollection.doc(`summary_${shortCode}`);
            await summaryRef.set({
              type: 'summary',
              shortCode,
              targetUrl: decodedUrl,
              totalClicks: admin.firestore.FieldValue.increment(1),
              lastClickAt: admin.firestore.FieldValue.serverTimestamp()
            }, { merge: true });
            
            console.log(`Emergency summary update completed for ${shortCode}`);
            trackingSucceeded = true;
          } catch (err) {
            console.error('Emergency click tracking also failed:', err);
          }
        }
      }
    } catch (err) {
      console.error('Error in click tracking process:', err);
      // Continue with the redirect even if tracking fails
    }
    
    // Verify if the document was created
    if (clickId) {
      try {
        const verifyDoc = await clicksCollection.doc(clickId).get();
        console.log(`Verification of click document: ${verifyDoc.exists ? 'Exists' : 'Does not exist'}`);
        if (verifyDoc.exists) {
          console.log('Document data:', JSON.stringify(verifyDoc.data()));
        }
      } catch (verifyError) {
        console.error(`Error verifying click document: ${verifyError}`);
      }
    }
    
    // Log the redirect
    console.log('Redirecting to:', {
      timestamp: new Date().toISOString(),
      shortCode,
      cfCountry,
      decodedUrl,
      trackingSucceeded,
      clickId
    });
    
    console.log(`==== REDIRECT REQUEST COMPLETED ====`);
    
    // Redirect to the target URL
    res.redirect(decodedUrl);
  } catch (error) {
    console.error('Error processing redirect:', error);
    res.status(500).send('Error processing redirect');
  }
});

// Add a default route to show a dashboard for URL shortening
app.use('*', (req, res) => {
  res.status(200).send(`
    <html>
      <head>
        <title>URL Shortener Dashboard</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f7f9fc;
            color: #333;
          }
          .container {
            max-width: 1000px; /* Increased width for more data */
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          }
          h1, h2, h3 {
            color: #4a3f9f;
          }
          .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
          }
          input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
          }
          button {
            background-color: #4a3f9f;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
          }
          button:hover {
            background-color: #3a2f8f;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
          }
          th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
          }
          th {
            background-color: #f2f2f2;
            font-weight: bold;
          }
          .copy-btn {
            background-color: #4CAF50;
            padding: 5px 10px;
            font-size: 0.8em;
          }
          .result {
            margin-top: 20px;
            padding: 15px;
            background-color: #f5f5f5;
            border-radius: 4px;
            word-break: break-all;
          }
          .tabs {
            display: flex;
            margin-bottom: 20px;
          }
          .tab {
            padding: 10px 20px;
            background-color: #e9f0fd;
            cursor: pointer;
            border-radius: 4px 4px 0 0;
            margin-right: 5px;
          }
          .tab.active {
            background-color: #4a3f9f;
            color: white;
          }
          .tab-content {
            display: none;
          }
          .tab-content.active {
            display: block;
          }
          .error {
            color: #D8000C;
            background-color: #FFBABA;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
            display: none;
          }
          .chart-container {
            height: 200px;
            position: relative;
            margin-top: 20px;
            margin-bottom: 20px;
          }
          .bar {
            position: absolute;
            bottom: 0;
            background-color: #4a3f9f;
            border-radius: 4px 4px 0 0;
            transition: height 0.3s;
            min-width: 30px;
            max-width: 60px;
          }
          .bar:hover::after {
            content: attr(data-value);
            position: absolute;
            top: -25px;
            left: 0;
            background: #333;
            color: white;
            padding: 3px 6px;
            border-radius: 3px;
            font-size: 12px;
          }
          .chart-label {
            position: absolute;
            bottom: -25px;
            text-align: center;
            font-size: 12px;
            transform: rotate(-45deg);
            transform-origin: top left;
            width: 40px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }
          .detailed-history {
            margin-top: 20px;
            border-top: 1px solid #ddd;
            padding-top: 20px;
          }
          .daily-clicks {
            margin-top: 15px;
          }
          .highlight-row {
            background-color: #f9f9f9;
          }
          .details-btn {
            background-color: #2196F3;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>URL Shortener Dashboard</h1>
          
          <div class="tabs">
            <div class="tab active" onclick="switchTab('single')">Single URL</div>
            <div class="tab" onclick="switchTab('bulk')">Bulk URLs</div>
            <div class="tab" onclick="switchTab('stats')">Statistics</div>
          </div>
          
          <div id="error-message" class="error"></div>
          
          <!-- Single URL Shortening -->
          <div id="single" class="tab-content active">
            <div class="card">
              <h2>Shorten URL</h2>
              <input type="url" id="url-input" placeholder="Enter URL to shorten (e.g. https://example.com)" />
              <button onclick="shortenUrl()">Shorten URL</button>
              
              <div id="result" class="result" style="display: none;">
                <p>Original URL: <a id="original-url-link" href="#" target="_blank"></a></p>
                <p>Shortened URL: <a id="short-url-link" href="#" target="_blank"></a></p>
                <button class="copy-btn" onclick="copyToClipboard('short-url-link')">Copy Link</button>
              </div>
            </div>
          </div>
          
          <!-- Bulk URL Shortening -->
          <div id="bulk" class="tab-content">
            <div class="card">
              <h2>Bulk URL Conversion</h2>
              <textarea id="bulk-urls" rows="5" placeholder="Enter multiple URLs, one per line"></textarea>
              <button onclick="bulkShortenUrls()">Convert All URLs</button>
              
              <div id="bulk-results" style="display: none;">
                <h3>Conversion Results</h3>
                <table id="results-table">
                  <thead>
                    <tr>
                      <th>Original URL</th>
                      <th>Shortened URL</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody id="results-body"></tbody>
                </table>
                <button class="copy-btn" style="margin-top: 10px;" onclick="copyAllLinks()">Copy All Links</button>
              </div>
            </div>
          </div>
          
          <!-- Click Statistics -->
          <div id="stats" class="tab-content">
            <div class="card">
              <h2>Click Statistics</h2>
              <button id="refreshStatsBtn" onclick="loadClickStatistics()">Refresh Statistics</button>
              
              <div id="stats-container">
                <table id="stats-table">
                  <thead>
                    <tr>
                      <th>Short Code</th>
                      <th>Short URL</th>
                      <th>Target URL</th>
                      <th>Total Clicks</th>
                      <th>Last Click</th>
                      <th>Top Countries</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody id="stats-body">
                    <tr>
                      <td colspan="7">Loading statistics...</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div id="detailed-stats" style="margin-top: 30px; display: none;">
                <h3 id="detailed-stats-title">Click History</h3>
                
                <div id="daily-clicks-chart" class="chart-container">
                  <!-- Bars will be added here dynamically -->
                </div>
                
                <div id="detailed-stats-content">
                  <h4>Click History</h4>
                  <table id="click-history-table">
                    <thead>
                      <tr>
                        <th>Date & Time</th>
                        <th>Country</th>
                        <th>Referrer</th>
                      </tr>
                    </thead>
                    <tbody id="click-history-body"></tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <script>
          // Tab switching logic
          function switchTab(tabId) {
            document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            document.querySelector('.tab[onclick="switchTab(\\''+tabId+'\\')"]').classList.add('active');
            document.getElementById(tabId).classList.add('active');
            
            if (tabId === 'stats') {
              loadClickStatistics();
            }
          }
          
          // Display error message
          function showError(message) {
            const errorElement = document.getElementById('error-message');
            errorElement.textContent = message;
            errorElement.style.display = 'block';
            
            setTimeout(() => {
              errorElement.style.display = 'none';
            }, 5000);
          }
          
          // Single URL shortening
          async function shortenUrl() {
            const urlInput = document.getElementById('url-input');
            const url = urlInput.value.trim();
            
            if (!url) {
              showError('Please enter a URL');
              return;
            }
            
            try {
              const response = await fetch('/api/shorten', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify({ url })
              });
              
              const data = await response.json();
              
              if (data.error) {
                showError(data.error);
                return;
              }
              
              const originalUrlLink = document.getElementById('original-url-link');
              originalUrlLink.textContent = data.originalUrl;
              originalUrlLink.href = data.originalUrl;
              
              const shortUrlLink = document.getElementById('short-url-link');
              shortUrlLink.textContent = data.shortUrl;
              shortUrlLink.href = data.shortUrl;
              document.getElementById('result').style.display = 'block';
            } catch (error) {
              showError('Error shortening URL: ' + error.message);
            }
          }
          
          // Bulk URL shortening
          async function bulkShortenUrls() {
            const bulkUrls = document.getElementById('bulk-urls').value.trim();
            
            if (!bulkUrls) {
              showError('Please enter at least one URL');
              return;
            }
            
            const urls = bulkUrls.split('\\n');
            const resultsBody = document.getElementById('results-body');
            resultsBody.innerHTML = '';
            
            const validLinks = [];
            
            for (const url of urls) {
              const trimmedUrl = url.trim();
              if (!trimmedUrl) continue;
              
              try {
                const response = await fetch('/api/shorten', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json'
                  },
                  body: JSON.stringify({ url: trimmedUrl })
                });
                
                const data = await response.json();
                
                if (data.error) {
                  const row = document.createElement('tr');
                  row.innerHTML = '<td>' + trimmedUrl + '</td><td><span style="color: red;">Error: ' + data.error + '</span></td><td>N/A</td>';
                  resultsBody.appendChild(row);
                } else {
                  const row = document.createElement('tr');
                  row.innerHTML = '<td><a href="' + data.originalUrl + '" target="_blank">' + data.originalUrl + '</a></td><td><a href="' + data.shortUrl + '" target="_blank">' + data.shortUrl + '</a></td><td><button class="copy-btn" onclick="copyText(\\'' + data.shortUrl + '\\')">Copy</button></td>';
                  resultsBody.appendChild(row);
                  
                  validLinks.push(data.shortUrl);
                }
              } catch (error) {
                const row = document.createElement('tr');
                row.innerHTML = '<td>' + trimmedUrl + '</td><td><span style="color: red;">Error processing URL</span></td><td>N/A</td>';
                resultsBody.appendChild(row);
              }
            }
            
            document.getElementById('bulk-results').style.display = 'block';
            
            // Store valid links for the "Copy All" button
            window.validLinks = validLinks;
          }
          
          // Copy functions
          function copyToClipboard(elementId) {
            const element = document.getElementById(elementId);
            copyText(element.textContent);
          }
          
          function copyText(text) {
            navigator.clipboard.writeText(text).then(() => {
              showError('Copied to clipboard!');
            }).catch(err => {
              showError('Failed to copy: ' + err);
            });
          }
          
          function copyAllLinks() {
            if (!window.validLinks || window.validLinks.length === 0) {
              showError('No valid links to copy');
              return;
            }
            
            const links = window.validLinks.join('\\n');
            navigator.clipboard.writeText(links).then(() => {
              showError('All links copied to clipboard!');
            }).catch(err => {
              showError('Failed to copy: ' + err);
            });
          }
          
          // Click statistics
          async function loadClickStatistics() {
            try {
              document.getElementById('refreshStatsBtn').disabled = true;
              document.getElementById('refreshStatsBtn').textContent = 'Loading...';
              
              const response = await fetch('/api/click-stats');
              const data = await response.json();
              
              const statsBody = document.getElementById('stats-body');
              statsBody.innerHTML = '';
              
              // Hide detailed stats section initially
              document.getElementById('detailed-stats').style.display = 'none';
              
              if (!data.stats || data.stats.length === 0) {
                const row = document.createElement('tr');
                row.innerHTML = '<td colspan="7">No click data available yet. Click some links to generate statistics.</td>';
                statsBody.appendChild(row);
                
                document.getElementById('refreshStatsBtn').disabled = false;
                document.getElementById('refreshStatsBtn').textContent = 'Refresh Statistics';
                return;
              }
              
              // Store stats data for later use when displaying details
              window.statsData = data.stats;
              
              let rowCounter = 0;
              for (const stat of data.stats) {
                const row = document.createElement('tr');
                if (rowCounter % 2 === 0) {
                  row.classList.add('highlight-row');
                }
                rowCounter++;
                
                const lastClickDate = stat.lastClickAt 
                  ? new Date(stat.lastClickAt).toLocaleString() 
                  : 'N/A';
                
                const shortUrl = 'https://dlzz.pro/r/' + stat.shortCode;
                
                // Format top countries
                let topCountries = 'None';
                if (stat.countryData && Object.keys(stat.countryData).length > 0) {
                  const countries = Object.entries(stat.countryData)
                    .sort((a, b) => b[1] - a[1])
                    .slice(0, 3)
                    .map(([country, count]) => country + ' (' + count + ')')
                    .join(', ');
                  
                  if (countries) {
                    topCountries = countries;
                  }
                }
                
                row.innerHTML = '<td>' + stat.shortCode + '</td>' +
                  '<td><a href="' + shortUrl + '" target="_blank">' + shortUrl + '</a></td>' +
                  '<td><a href="' + stat.targetUrl + '" target="_blank">' + stat.targetUrl + '</a></td>' +
                  '<td>' + stat.totalClicks + '</td>' +
                  '<td>' + lastClickDate + '</td>' +
                  '<td>' + topCountries + '</td>' +
                  '<td>' +
                    '<button class="copy-btn" onclick="copyText(\\'' + shortUrl + '\\')">Copy</button>' +
                    '<button class="details-btn" style="margin-left: 5px;" onclick="showClickDetails(\\'' + stat.shortCode + '\\')">Details</button>' +
                  '</td>';
                
                statsBody.appendChild(row);
              }
              
              document.getElementById('refreshStatsBtn').disabled = false;
              document.getElementById('refreshStatsBtn').textContent = 'Refresh Statistics';
            } catch (error) {
              console.error('Error loading statistics:', error);
              showError('Error loading statistics: ' + error.message);
              
              const statsBody = document.getElementById('stats-body');
              statsBody.innerHTML = '<tr><td colspan="7">Error loading statistics. Please try again.</td></tr>';
              
              document.getElementById('refreshStatsBtn').disabled = false;
              document.getElementById('refreshStatsBtn').textContent = 'Refresh Statistics';
            }
          }
          
          // Show click details for a specific short code
          function showClickDetails(shortCode) {
            const stat = window.statsData.find(s => s.shortCode === shortCode);
            if (!stat) return;
            
            const detailedStats = document.getElementById('detailed-stats');
            const detailedStatsTitle = document.getElementById('detailed-stats-title');
            const clickHistoryBody = document.getElementById('click-history-body');
            const dailyClicksChart = document.getElementById('daily-clicks-chart');
            
            detailedStatsTitle.textContent = 'Statistics for ' + shortCode;
            clickHistoryBody.innerHTML = '';
            dailyClicksChart.innerHTML = '';
            
            // Generate daily clicks chart if we have data
            if (stat.dailyClickData && Object.keys(stat.dailyClickData).length > 0) {
              const days = Object.keys(stat.dailyClickData).sort();
              
              // Find the maximum clicks for scaling
              const maxClicks = Math.max(...Object.values(stat.dailyClickData));
              
              // Calculate the width per bar
              const chartWidth = dailyClicksChart.offsetWidth;
              const barWidth = Math.min(60, Math.max(30, chartWidth / days.length - 10));
              
              // Generate bars
              days.forEach((day, index) => {
                const clicks = stat.dailyClickData[day];
                const heightPercentage = (clicks / maxClicks) * 100;
                const actualHeight = Math.max(20, heightPercentage * 1.8); // Minimum height for visibility
                
                const bar = document.createElement('div');
                bar.className = 'bar';
                bar.style.height = actualHeight + 'px';
                bar.style.width = barWidth + 'px';
                bar.style.left = (index * (barWidth + 10)) + 'px';
                bar.setAttribute('data-value', clicks + ' clicks');
                
                const label = document.createElement('div');
                label.className = 'chart-label';
                label.textContent = day;
                label.style.left = (index * (barWidth + 10)) + (barWidth / 2) + 'px';
                
                dailyClicksChart.appendChild(bar);
                dailyClicksChart.appendChild(label);
              });
            } else {
              dailyClicksChart.innerHTML = '<p>No daily click data available</p>';
            }
            
            // Show click history
            if (!stat.recentClicks || stat.recentClicks.length === 0) {
              clickHistoryBody.innerHTML = '<tr><td colspan="3">No detailed click data available</td></tr>';
            } else {
              stat.recentClicks.forEach(click => {
                const row = document.createElement('tr');
                const timestamp = click.timestamp instanceof Date ? 
                  click.timestamp.toLocaleString() : 
                  new Date(click.timestamp).toLocaleString();
                
                row.innerHTML = 
                  '<td>' + timestamp + '</td>' +
                  '<td>' + (click.country || 'Unknown') + '</td>' +
                  '<td>' + (click.referrer || 'Direct') + '</td>';
                
                clickHistoryBody.appendChild(row);
              });
            }
            
            detailedStats.style.display = 'block';
            
            // Scroll to the detailed stats
            detailedStats.scrollIntoView({ behavior: 'smooth' });
          }
          
          // Load stats on page load if stats tab is active
          document.addEventListener('DOMContentLoaded', function() {
            if (document.querySelector('#stats').classList.contains('active')) {
              loadClickStatistics();
            }
          });
        </script>
      </body>
    </html>
  `);
});

// Add this with other API endpoints, before exporting the Cloud Function
app.get('/api/diagnose', diagnosePage.diagnoseHandler);

// Add a new endpoint to check in-memory clicks (last resort tracking)
app.get('/api/memory-clicks', (req, res) => {
  try {
    // Return the in-memory clicks if any
    if (!global.inMemoryClicks) global.inMemoryClicks = [];
    
    // Add function instance metadata
    const info = {
      functionInstance: crypto.randomBytes(4).toString('hex'),
      startupTime: global.serverStartTime || new Date().toISOString(),
      memoryClicks: global.inMemoryClicks,
      totalCount: global.inMemoryClicks.length,
      message: global.inMemoryClicks.length > 0 
        ? 'In-memory clicks found! This means Firestore tracking failed.' 
        : 'No in-memory clicks found. Either no clicks occurred or Firestore tracking worked.'
    };
    
    res.json(info);
  } catch (error) {
    console.error('Error serving memory clicks:', error);
    res.status(500).json({ error: 'Failed to retrieve memory clicks' });
  }
});

// Add this right after so we can capture server start time
global.serverStartTime = new Date().toISOString();

// Export the Cloud Function with dynamic import handling
exports.api = functions.https.onRequest(async (req, res) => {
  try {
    // Log all incoming requests in detail
    console.log('REQUEST:', {
      path: req.path,
      method: req.method,
      cookies: req.cookies ? Object.keys(req.cookies) : 'none',
      host: req.headers.host,
      origin: req.headers.origin,
      referer: req.headers.referer
    });
    
    // Forward all requests to our Express app
    return app(req, res);
  } catch (error) {
    console.error('Unhandled error in function:', error);
    res.status(500).send('Server error: ' + error.message);
  }
});

// Initialize the server when the module is loaded
(async () => {
  console.log('Server initialization complete');
})();